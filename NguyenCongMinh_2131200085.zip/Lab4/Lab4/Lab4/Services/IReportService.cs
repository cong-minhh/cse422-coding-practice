public interface IReportService
{
    string GenerateBorrowingReport();
} 